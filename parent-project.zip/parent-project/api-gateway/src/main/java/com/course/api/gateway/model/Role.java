package com.course.api.gateway.model;

public enum Role {

    USER,
    ADMIN
}
