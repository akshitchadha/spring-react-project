package com.coursepurchase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicroservice2CoursePurchaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicroservice2CoursePurchaseApplication.class, args);
	}

}
