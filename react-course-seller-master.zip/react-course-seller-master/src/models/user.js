
export default class User {
    constructor(username, password, name, role, token, id) {
        this.username = username;
        this.password = password;
        this.name = name;
        this.role = role;
        this.token = token;
        this.id = id;
    }
}
