export default class Course {
    constructor(title, subtitle, price, createTime, id) {
        this.title = title;
        this.subtitle = subtitle;
        this.price = price;
        this.createTime = createTime;
        this.id = id;
    }
}
